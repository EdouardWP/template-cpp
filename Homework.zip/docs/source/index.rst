|project| documentation
===================================

Welcome to the landing page!

A section
----------

.. doxygennamespace:: homework


Docs
====

.. toctree::
   :maxdepth: 2
   :caption: Contents:

